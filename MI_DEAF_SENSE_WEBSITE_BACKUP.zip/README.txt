This is a basic placeholder website for mideafsense.co.za

Includes:
- index.html (Home page)
- css/style.css (Basic styling)
- Structure prepared for future development

Instructions:
This site is temporary. Once development is complete, replace this with your actual WordPress or HTML site.

Created by: Ketani (AI Assistant) for Khulekani Trevor Ngcobo, 2025
